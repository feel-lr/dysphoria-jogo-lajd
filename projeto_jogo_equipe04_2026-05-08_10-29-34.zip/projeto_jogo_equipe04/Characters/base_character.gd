extends CharacterBody2D
class_name BaseCharacter

@export_category("Variables")
@export var _move_speed: float = 300.0

@export_category("Objects")

@onready var _sprite = $AnimatedSprite2D


func _physics_process(_delta: float) -> void:
	var _direction := Vector2.ZERO 
	_direction.x = Input.get_axis("move_left", "move_right")
	_direction.y = Input.get_axis("move_up", "move_down")
	
	if _direction != Vector2.ZERO:
		_direction = _direction.normalized()
		velocity = _direction * _move_speed
		_atualizar_animacao_run(_direction)
	else:
		velocity = Vector2.ZERO	
		_sprite.play("Idle")
	move_and_slide()
	
func _atualizar_animacao_run(dir: Vector2) -> void:
	if abs(dir.y) >= abs(dir.x):
		if dir.y < 0:
			_sprite.play("Run_Back")
		else:
			_sprite.play("Run_Forward")
	else:
		_sprite.play("Run_Lateral")
		_sprite.flip_h = dir.x > 0
			
	
	
