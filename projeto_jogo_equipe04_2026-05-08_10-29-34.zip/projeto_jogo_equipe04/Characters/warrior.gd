extends CharacterBody2D


@export_category("Variables")
@export var _move_speed: float = 300.0

@onready var _sprite = $AnimatedSprite2D

func _physics_process(_delta: float) -> void:
	_move()
	_animation()
	
	
func _move() -> void:
	var _direction: Vector2 = Input.get_vector(
		"move_left", "move_right", "move_up", "move_down"
	) 
	velocity = _direction * _move_speed
	move_and_slide()
	
	
func _animation() -> void:
	if velocity.x > 0:
		_sprite.flip_h = false
		
	if velocity.x < 0:
		_sprite.flip_h = true
	
	if velocity:
		_sprite.play("WarriorRun")
		return
		
	_sprite.play("WarriorIdle")
	
