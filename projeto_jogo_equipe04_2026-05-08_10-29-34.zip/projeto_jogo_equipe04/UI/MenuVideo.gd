extends TextureRect


func _on_tela_cheia_controle_toggled(toggled_on: bool) -> void:
	if toggled_on == true:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)

func _on_voltar_pressed() -> void:
	SceneManager.go_to("res://UI/MenuOpcoes.tscn", false)
		 
