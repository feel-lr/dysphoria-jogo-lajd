extends TextureRect

@export var menu_opcoes: PackedScene
@export var music_menu: AudioStream

func _ready() -> void:
	AudioController.tocar_musica(music_menu)


func _on_jogar_pressed() -> void:
	AudioController.parar_musica()
	SceneManager.go_to("res://GameLevels/quarto.tscn")
	

func _on_opcoes_pressed() -> void:
	SceneManager.go_to("res://UI/MenuOpcoes.tscn", false)


func _on_sair_pressed() -> void:
	get_tree().quit()
	
