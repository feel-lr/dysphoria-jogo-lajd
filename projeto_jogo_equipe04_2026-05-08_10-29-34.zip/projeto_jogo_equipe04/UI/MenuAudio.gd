extends TextureRect


@export var audio_bus_name: String

var audio_bus_id

func _ready():
	audio_bus_id = AudioServer.get_bus_index(audio_bus_name)

func _on_music_volume_value_changed(value: float) -> void:
	var db = linear_to_db(value)
	AudioServer.set_bus_volume_db(audio_bus_id, db)



func _on_voltar_pressed() -> void:
	SceneManager.go_to("res://UI/MenuOpcoes.tscn", false)
