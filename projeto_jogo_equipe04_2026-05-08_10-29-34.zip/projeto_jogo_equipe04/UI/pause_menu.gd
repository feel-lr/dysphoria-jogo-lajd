extends Control

func _on_continuar_pressed() -> void:
	PauseManager.toggle()

func _on_menu_principal_pressed() -> void:
	PauseManager.toggle()                                        # despausa primeiro
	SceneManager.go_to("res://UI/MenuPrincipal.tscn", false)    # vai pro menu

func _on_sair_pressed() -> void:
	get_tree().quit()
