extends TextureRect


func _on_voltar_pressed() -> void:
	SceneManager.go_to("res://UI/MenuPrincipal.tscn", false)
	

func _on_audio_pressed() -> void:
	SceneManager.go_to("res://UI/MenuAudio.tscn", false)


func _on_video_pressed() -> void:
	SceneManager.go_to("res://UI/MenuVideo.tscn", false)
