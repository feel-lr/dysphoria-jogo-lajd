extends Node

signal scene_changed(scene_name: String)

var _current_scene: Node = null
var _scene_layer: Node = null
var _transition: AnimationPlayer = null

func initialize(scene_layer: Node, transition: AnimationPlayer) -> void:
	_scene_layer = scene_layer
	_transition = transition

func go_to(scene_path: String, use_transition: bool = true) -> void:
	if _scene_layer == null or _transition == null:
		push_error("SceneManager não foi inicializado! Chame initialize() na Main primeiro.")
		return
	
	if use_transition:
		_transition.play("fade_out")  # escurece
		await _transition.animation_finished
	
	# Remove cena atual
	if _current_scene:
		_current_scene.queue_free()
	
	# Carrega nova cena
	var new_scene = load(scene_path).instantiate()
	_scene_layer.add_child(new_scene)
	_current_scene = new_scene
	
	if use_transition:
		_transition.play("fade_in")   # clareia
		scene_changed.emit(new_scene.name)
		
func is_game_level() -> bool:
	if _current_scene == null:
		return false
	return _current_scene.scene_file_path.contains("GameLevels")
