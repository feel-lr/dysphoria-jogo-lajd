# pause_manager.gd
extends Node

var _pause_layer: CanvasLayer = null
var _pause_menu: Node = null
var _pause_scene = preload("res://UI/PauseMenu.tscn")
var is_paused: bool = false

func initialize(pause_layer: CanvasLayer) -> void:
	_pause_layer = pause_layer

func toggle() -> void:
	if is_paused:
		_unpause()
	else:
		_pause()

func _pause() -> void:
	is_paused = true
	get_tree().paused = true                        # pausa o jogo inteiro
	_pause_menu = _pause_scene.instantiate()
	_pause_layer.add_child(_pause_menu)

func _unpause() -> void:
	is_paused = false
	get_tree().paused = false
	if _pause_menu:
		_pause_menu.queue_free()
		_pause_menu = null
