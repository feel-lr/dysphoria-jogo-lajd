extends Node2D

@onready var music_menu = $AudioStreamPlayer

func _ready() -> void:
	#Garantir que o Nó não seja destruído ao trocar de Cena
	process_mode = Node.PROCESS_MODE_ALWAYS

func tocar_musica(stream: AudioStream) -> void:
	if music_menu.stream == stream and music_menu.playing:
		return #Já está tocando essa musica, não reinicia
	music_menu.stream = stream
	music_menu.play()

func parar_musica() -> void:
	music_menu.stop()
	
func pausar_musica() -> void:
	music_menu.stream_paused = true
	
func retomar_musica() -> void:
	music_menu.stream_paused = false
