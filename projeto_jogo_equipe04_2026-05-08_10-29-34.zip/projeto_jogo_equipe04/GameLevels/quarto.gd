extends Node2D

var porta_perto_player := false
var tv_perto_player := false
var abajur_perto_player := false
var cama_perto_player := false
var estante_perto_player := false
var livros_perto_player := false
var guarda_roupa_perto_player := false

@onready var _animacao = $AnimationPlayer
@onready var _interaction_label: Label = $Yuji/InteractionLabel1

func _ready() -> void:
	Dialogic.timeline_started.connect(_on_dialog_started)
	Dialogic.timeline_ended.connect(_on_dialog_ended)
	Dialogic.signal_event.connect(_on_dialogic_signal)
	Dialogic.start("res://GameLevels/DialogoQuarto/timelineQuarto.dtl")
	_interaction_label.visible = false
	_interaction_label.text = "[E] para interagir"
	
func _set_label_visivel(visivel: bool) -> void:
	_interaction_label.visible = visivel

func _on_dialog_started() -> void:
	# Desativa só o que precisa parar
	$Yuji.set_process(false)
	$Yuji.set_physics_process(false)
	$Yuji.set_process_input(false)
	_set_label_visivel(false)
	
	# Se tiver inimigos num grupo:
	# get_tree().call_group("enemies", "set_process", false)
	# get_tree().call_group("enemies", "set_physics_process", false)

func _on_dialog_ended() -> void:
	# Reativa tudo
	$Yuji.set_process(true)
	$Yuji.set_physics_process(true)
	$Yuji.set_process_input(true)
	
	# get_tree().call_group("enemies", "set_process", true)
	# get_tree().call_group("enemies", "set_physics_process", true)
	
func _input(event: InputEvent) -> void:
	if not event.is_action_pressed("interact"):
		return
	if Dialogic.current_timeline:  # bloqueia se já tem diálogo rolando
		return
	
	if tv_perto_player:
		_interagir_tv()
		
	if cama_perto_player:
		Dialogic.start("res://GameLevels/DialogoQuarto/interacaoCama.dtl")
		
	if estante_perto_player:
		Dialogic.start("res://GameLevels/DialogoQuarto/interacaoEstante.dtl")
		
	if abajur_perto_player:
		Dialogic.start("res://GameLevels/DialogoQuarto/interacaoAbajur.dtl")
		
	if livros_perto_player:
		Dialogic.start("res://GameLevels/DialogoQuarto/interacaoLivros.dtl")
	
	if porta_perto_player:
		Dialogic.start("res://GameLevels/DialogoQuarto/interacaoPorta.dtl")
		
	if guarda_roupa_perto_player:
		_interagir_guarda_roupa()
	
	
	
	
	
#--- INTERACAO TV - CONTROLE --- #
func _interagir_tv() -> void:
	var possui_controle_tv: bool = Dialogic.VAR.possui_controle_tv
	var _tv_desliga: bool = Dialogic.VAR.tv_desligada
	
	if possui_controle_tv:
		Dialogic.start("res://GameLevels/DialogoQuarto/interacaoTvComControle.dtl")
		_animacao.play("tv_light")
		
	else:
		Dialogic.start("res://GameLevels/DialogoQuarto/interacaoTv.dtl")
		_animacao.play("RESET")
		
func _on_dialogic_signal(signal_name: String) -> void:
	match signal_name:
		"tv_desliga":
			_animacao.play("RESET")
		"tv_liga":
			_animacao.play("tv_light")
		"portal_cresce":
			_animacao.play("portal_crescendo")
			_animacao.animation_finished.connect(_on_portal_crescendo_finished, CONNECT_ONE_SHOT)
		"fim_level":
			await Dialogic.timeline_ended
			SceneManager.go_to("res://GameLevels/level_2.tscn", true)
			
func _on_portal_crescendo_finished(anim_name: String) -> void:
	if anim_name == "portal_crescendo":
		_animacao.play("portal")

# --- INTERACAO GUARDA-ROUPA ABERTO --- #
func _interagir_guarda_roupa() -> void:
	var _abrir_guarda_roupa: bool = Dialogic.VAR.abrir_guarda_roupa
	Dialogic.start("res://GameLevels/DialogoQuarto/interacaoGuardaRoupa.dtl")
	_animacao.play("guarda_roupa_aberto")
	


# --- TV --- #
func _on_tv_collision_body_entered(body: Node2D) -> void:
	if body.name == "Yuji":
		tv_perto_player = true
		_set_label_visivel(true)
		
		
func _on_tv_collision_body_exited(body: Node2D) -> void:
	if body.name == "Yuji":
		tv_perto_player = false
		_set_label_visivel(false)
		



# --- CAMA --- #
func _on_cama_collision_body_entered(body: Node2D) -> void:
	if body.name == "Yuji":
		cama_perto_player = true
		_set_label_visivel(true)
		

func _on_cama_collision_body_exited(body: Node2D) -> void:
	if body.name == "Yuji":
		cama_perto_player = false
		_set_label_visivel(false)
		



# --- ESTANTE --- #
func _on_estante_collision_body_entered(body: Node2D) -> void:
	if body.name == "Yuji":
		estante_perto_player = true
		_set_label_visivel(true)

func _on_estante_collision_body_exited(body: Node2D) -> void:
	if body.name == "Yuji":
		estante_perto_player = false
		_set_label_visivel(false)



# --- ABAJUR --- #
func _on_abajur_collision_body_entered(body: Node2D) -> void:
	if body.name == "Yuji":
		abajur_perto_player = true
		_set_label_visivel(true)

func _on_abajur_collision_body_exited(body: Node2D) -> void:
	if body.name == "Yuji":
		abajur_perto_player = false
		_set_label_visivel(false)



# --- LIVROS --- #
func _on_livros_collision_body_entered(body: Node2D) -> void:
	if body.name == "Yuji":
		livros_perto_player = true
		_set_label_visivel(true)
		

func _on_livros_collision_body_exited(body: Node2D) -> void:
	if body.name == "Yuji":
		livros_perto_player = false
		_set_label_visivel(false)
		
	


# --- PORTA --- #
func _on_porta_collision_body_entered(body: Node2D) -> void:
	if body.name == "Yuji":
		porta_perto_player = true
		_set_label_visivel(true)

func _on_porta_collision_body_exited(body: Node2D) -> void:
	if body.name == "Yuji":
		porta_perto_player = false
		_set_label_visivel(false)
	
	

# --- GUARDA-ROUPA --- #
func _on_guarda_roupa_collision_body_entered(body: Node2D) -> void:
	if body.name == "Yuji":
		guarda_roupa_perto_player = true
		_set_label_visivel(true)
		

func _on_guarda_roupa_collision_body_exited(body: Node2D) -> void:
	if body.name == "Yuji":
		guarda_roupa_perto_player = false
		_animacao.play("RESET")
		_set_label_visivel(false)
