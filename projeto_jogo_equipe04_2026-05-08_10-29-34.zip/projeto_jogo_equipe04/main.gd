extends Node

@onready var _scene_layer = $SceneLayer
@onready var _transition = $TransitionLayer/AnimationPlayer
@onready var _pause_layer = $PauseLayer

func _ready() -> void:
	# Inicializa o SceneManager com as referências necessárias
	SceneManager.initialize(_scene_layer, _transition)
	PauseManager.initialize(_pause_layer)
	# Começa pelo menu principal
	SceneManager.go_to("res://UI/MenuPrincipal.tscn", false)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):   # ESC 
		# Só pausa se estiver num GameLevel, não no menu
		if SceneManager.is_game_level():
			PauseManager.toggle()
